//  <script>
// Get all FAQ items
const faqItems = document.querySelectorAll(".faq-item");

// Add click event listener to each FAQ item
faqItems.forEach((item) => {
  const question = item.querySelector(".faq-question");

  // Handle both click and keyboard events
  question.addEventListener("click", toggleFAQ);
  question.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      toggleFAQ.call(question);
    }
  });
});

function toggleFAQ() {
  // Close all other items
  const currentItem = this.parentElement;
  const wasOpen = currentItem.classList.contains("active");

  // Close all items
  document.querySelectorAll(".faq-item").forEach((item) => {
    // item.classList.remove("active");
  });

  // If the clicked item wasn't open, open it
  if (!wasOpen) {
    currentItem.classList.add("active");
  }
  if (wasOpen) {
    currentItem.classList.remove("active");
  }
}

document.querySelector(".go-button").addEventListener("click", () => {
  const from = document.getElementById("from").value;
  const to = document.getElementById("to").value;
  console.log(`Converting from ${from} to ${to}`);
});
// Optional: Open first item by default
// document.querySelector('.faq-item').classList.add('active');
// </script>

let currentSlide = 0;
const slides = document.querySelectorAll(".slide");

// Function to show a specific slide
function showSlide(n) {
  slides.forEach((slide, index) => {
    slide.classList.toggle("active", index === n);
  });
  currentSlide = n;
}

// Next/previous controls
document.querySelector(".prev").addEventListener("click", () => {
  showSlide((currentSlide - 1 + slides.length) % slides.length);
});

document.querySelector(".next").addEventListener("click", () => {
  showSlide((currentSlide + 1) % slides.length);
});

// Auto advance slides every 5 seconds
let slideInterval = setInterval(() => {
  showSlide((currentSlide + 1) % slides.length);
}, 5000);

// Pause auto-advance on hover
const slideshow = document.querySelector(".slideshow-container");
slideshow.addEventListener("mouseenter", () => {
  clearInterval(slideInterval);
});

slideshow.addEventListener("mouseleave", () => {
  slideInterval = setInterval(() => {
    showSlide((currentSlide + 1) % slides.length);
  }, 5000);
});

// Keyboard navigation
document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowLeft") {
    showSlide((currentSlide - 1 + slides.length) % slides.length);
  } else if (e.key === "ArrowRight") {
    showSlide((currentSlide + 1) % slides.length);
  }
});

const menuButton = document.querySelector(".menu-button");
const sidebar = document.querySelector(".sidebar");
const search = document.querySelector(".search");

menuButton.addEventListener("mouseover", () => {
  if (sidebar.style.right === "0px") {
    sidebar.style.right = "-350px";
    search.style.display = "none";
  } else {
    sidebar.style.right = "0px";
    search.style.display = "flex";
  }
});
sidebar.addEventListener("mouseleave", () => {
  sidebar.style.right = "-350px";
  search.style.display = "none";
});

const themes = ["white", "black", "pink", "slate", "green"];
let currentThemeIndex = 0;

document.getElementById("theme-toggle").addEventListener("click", () => {
  currentThemeIndex = (currentThemeIndex + 1) % themes.length;
  const newTheme = themes[currentThemeIndex];
  document.documentElement.setAttribute("data-theme", newTheme);
});

const container = document.querySelector(".carousel-container");
const originalItems = container.innerHTML;
container.innerHTML = originalItems + originalItems;

document.querySelectorAll(".icon-wrapper").forEach((item) => {
  item.addEventListener("click", () => {
    document.querySelectorAll(".icon-wrapper").forEach((i) => {
      i.classList.remove("click-animate");
    });

    item.classList.add("click-animate");

    setTimeout(() => {
      item.classList.remove("click-animate");
    }, 500);
  });
});

document.querySelectorAll(".carousel-item").forEach((item) => {
  item.addEventListener("click", () => {
    document.querySelectorAll(".carousel-item").forEach((i) => {
      i.classList.remove("selected");
    });

    const svgPath = item.querySelector("svg path").getAttribute("d");
    document.querySelectorAll(".carousel-item").forEach((i) => {
      if (i.querySelector("svg path").getAttribute("d") === svgPath) {
        i.classList.add("selected");
      }
    });
  });
});

container.addEventListener("animationend", () => {
  container.style.animation = "none";
  container.offsetHeight;
  container.style.animation = null;
});

const chatButton = document.getElementById("chat-button1");
const chatBox = document.getElementById("chat-box");
const closeButton = document.getElementById("close-button");

chatButton.addEventListener("click", () => {
  chatBox.style.display = "block";
  chatButton.style.display = "none";
});

closeButton.addEventListener("click", () => {
  chatBox.style.display = "none";
  chatButton.style.display = "block";
});
